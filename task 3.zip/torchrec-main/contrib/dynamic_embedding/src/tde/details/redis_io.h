#pragma once

namespace tde::details {

extern void RegisterRedisIO();

}
