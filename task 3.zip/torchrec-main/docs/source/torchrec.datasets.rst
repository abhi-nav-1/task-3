torchrec.datasets
=================

.. automodule:: torchrec.datasets

torchrec.datasets.criteo
------------------------

.. automodule:: torchrec.datasets.criteo
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.datasets.movielens
---------------------------

.. automodule:: torchrec.datasets.movielens
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.datasets.random
------------------------

.. automodule:: torchrec.datasets.random
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.datasets.utils
-----------------------

.. automodule:: torchrec.datasets.utils
   :members:
   :undoc-members:
   :show-inheritance:
