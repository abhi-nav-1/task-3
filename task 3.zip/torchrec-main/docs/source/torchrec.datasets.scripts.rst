torchrec.datasets.scripts
=========================

.. automodule:: torchrec.datasets.scripts



torchrec.datasets.scripts.contiguous\_preproc\_criteo
-----------------------------------------------------

.. automodule:: torchrec.datasets.scripts.contiguous_preproc_criteo
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.datasets.scripts.npy\_preproc\_criteo
----------------------------------------------

.. automodule:: torchrec.datasets.scripts.npy_preproc_criteo
   :members:
   :undoc-members:
   :show-inheritance:
