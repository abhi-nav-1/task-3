torchrec.distributed.planner
============================

.. automodule:: torchrec.distributed.planner


torchrec.distributed.planner.constants
--------------------------------------

.. automodule:: torchrec.distributed.planner.constants
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.enumerators
----------------------------------------

.. automodule:: torchrec.distributed.planner.enumerators
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.partitioners
-----------------------------------------

.. automodule:: torchrec.distributed.planner.partitioners
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.perf\_models
-----------------------------------------

.. automodule:: torchrec.distributed.planner.perf_models
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.planners
-------------------------------------

.. automodule:: torchrec.distributed.planner.planners
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.proposers
--------------------------------------

.. automodule:: torchrec.distributed.planner.proposers
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.shard\_estimators
----------------------------------------------

.. automodule:: torchrec.distributed.planner.shard_estimators
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.stats
----------------------------------

.. automodule:: torchrec.distributed.planner.stats
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.storage\_reservations
--------------------------------------------------

.. automodule:: torchrec.distributed.planner.storage_reservations
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.types
----------------------------------

.. automodule:: torchrec.distributed.planner.types
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.planner.utils
----------------------------------

.. automodule:: torchrec.distributed.planner.utils
   :members:
   :undoc-members:
   :show-inheritance:
