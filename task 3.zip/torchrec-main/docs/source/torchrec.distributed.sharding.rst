torchrec.distributed.sharding
=============================

.. automodule:: torchrec.distributed.sharding


torchrec.distributed.sharding.cw\_sharding
------------------------------------------

.. automodule:: torchrec.distributed.sharding.cw_sharding
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.dist\_data
-------------------------------

.. automodule:: torchrec.distributed.dist_data
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.sharding.dp\_sharding
------------------------------------------

.. automodule:: torchrec.distributed.sharding.dp_sharding
   :members:
   :undoc-members:
   :show-inheritance:


torchrec.distributed.sharding.rw\_sharding
------------------------------------------

.. automodule:: torchrec.distributed.sharding.rw_sharding
   :members:
   :undoc-members:
   :show-inheritance:


torchrec.distributed.sharding.tw\_sharding
------------------------------------------

.. automodule:: torchrec.distributed.sharding.tw_sharding
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.sharding.twcw\_sharding
--------------------------------------------

.. automodule:: torchrec.distributed.sharding.twcw_sharding
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.distributed.sharding.twrw\_sharding
--------------------------------------------

.. automodule:: torchrec.distributed.sharding.twrw_sharding
   :members:
   :undoc-members:
   :show-inheritance:
