torchrec.fx
===========

.. automodule:: torchrec.fx

torchrec.fx.tracer
------------------

.. automodule:: torchrec.fx.tracer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.fx
   :members:
   :undoc-members:
   :show-inheritance:
