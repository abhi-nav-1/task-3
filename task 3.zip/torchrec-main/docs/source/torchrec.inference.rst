torchrec.inference
===========

.. automodule:: torchrec.inference

torchrec.inference.model_packager
------------------

.. automodule:: torchrec.inference.model_packager
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.inference.modules
------------------

.. automodule:: torchrec.inference.modules
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.inference
   :members:
   :undoc-members:
   :show-inheritance:
