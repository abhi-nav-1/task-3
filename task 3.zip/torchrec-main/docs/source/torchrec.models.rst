torchrec.models
===============

.. automodule:: torchrec.models

torchrec.models.deepfm
----------------------

.. automodule:: torchrec.models.deepfm
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.models.dlrm
--------------------

.. automodule:: torchrec.models.dlrm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.models
   :members:
   :undoc-members:
   :show-inheritance:
