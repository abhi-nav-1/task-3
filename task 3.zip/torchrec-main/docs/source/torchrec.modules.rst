torchrec.modules
================

.. automodule:: torchrec.modules

torchrec.modules.activation
---------------------------

.. automodule:: torchrec.modules.activation
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.crossnet
-------------------------

.. automodule:: torchrec.modules.crossnet
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.deepfm
-----------------------

.. automodule:: torchrec.modules.deepfm
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.embedding\_configs
-----------------------------------

.. automodule:: torchrec.modules.embedding_configs
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.embedding\_modules
-----------------------------------

.. automodule:: torchrec.modules.embedding_modules
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.feature\_processor
-----------------------------------

.. automodule:: torchrec.modules.feature_processor
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.lazy\_extension
--------------------------------

.. automodule:: torchrec.modules.lazy_extension
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.mlp
--------------------

.. automodule:: torchrec.modules.mlp
   :members:
   :undoc-members:
   :show-inheritance:


torchrec.modules.utils
----------------------

.. automodule:: torchrec.modules.utils
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.mc_modules
---------------

.. automodule:: torchrec.modules.mc_modules
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.modules.mc_embedding_modules
---------------

.. automodule:: torchrec.modules.mc_embedding_modules
   :members:
   :undoc-members:
   :show-inheritance:
