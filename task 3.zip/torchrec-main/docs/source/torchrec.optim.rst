torchrec.optim
==============

.. automodule:: torchrec.optim

torchrec.optim.clipping
-----------------------

.. automodule:: torchrec.optim.clipping
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.optim.fused
--------------------

.. automodule:: torchrec.optim.fused
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.optim.keyed
--------------------

.. automodule:: torchrec.optim.keyed
   :members:
   :undoc-members:
   :show-inheritance:

torchrec.optim.warmup
---------------------

.. automodule:: torchrec.optim.warmup
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.optim
   :members:
   :undoc-members:
   :show-inheritance:
