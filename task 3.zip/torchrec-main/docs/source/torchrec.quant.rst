torchrec.quant
==============

.. automodule:: torchrec.quant

torchrec.quant.embedding\_modules
---------------------------------

.. automodule:: torchrec.quant.embedding_modules
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.quant
   :members:
   :undoc-members:
   :show-inheritance:
