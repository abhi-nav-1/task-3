torchrec.sparse
===============

.. automodule:: torchrec.sparse

torchrec.sparse.jagged\_tensor
------------------------------

.. automodule:: torchrec.sparse.jagged_tensor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: torchrec.sparse
   :members:
   :undoc-members:
   :show-inheritance:
