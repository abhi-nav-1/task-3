# Golden Training Example

## Running
`torchx run -s local_cwd dist.ddp -j 1x2 --script train_dlrm.py`
